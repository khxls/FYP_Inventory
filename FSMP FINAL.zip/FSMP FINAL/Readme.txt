A practical project using php,html,css,bootstrap4,mysql,xampp for industrial attachment .
